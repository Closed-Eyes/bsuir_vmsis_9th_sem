// Resources prefix
var s_resprefix = "res/";

var s_pathGrossini = "res/Images/grossini.png";
var s_pathSister1 = "res/Images/grossinis_sister1.png";
var s_pathSister2 = "res/Images/grossinis_sister2.png";
var s_pathB1 = "res/Images/b1.png";
var s_pathB2 = "res/Images/b2.png";
var s_pathR1 = "res/Images/r1.png";
var s_pathR2 = "res/Images/r2.png";
var s_pathF1 = "res/Images/f1.png";
var s_pathF2 = "res/Images/f2.png";
var s_pathBlock = "res/Images/blocks.png";
var s_back = "res/Images/background.png";
var s_back1 = "res/Images/background1.png";
var s_back2 = "res/Images/background2.png";
var s_back3 = "res/Images/background3.png";
var s_stars1 = "res/Images/stars.png";
var s_stars2 = "res/Images/stars2.png";
var s_fire = "res/Images/fire.png";
var s_snow = "res/Images/snow.png";
var s_streak = "res/Images/streak.png";
var s_playNormal = "res/Images/btn-play-normal.png";
var s_playSelect = "res/Images/btn-play-selected.png";
var s_aboutNormal = "res/Images/btn-about-normal.png";
var s_aboutSelect = "res/Images/btn-about-selected.png";
var s_highNormal = "res/Images/btn-highscores-normal.png";
var s_highSelect = "res/Images/btn-highscores-selected.png";
var s_ball = "res/Images/ball.png";
var s_paddle = "res/Images/paddle.png";
var s_pathClose = "res/Images/close.png";
var s_menuItem = "res/Images/menuitemsprite.png";
var s_shapeModeMenuItem = "res/Images/shapemode.png";
var s_textureModeMenuItem = "res/Images/texturemode.png";
var s_MovementMenuItem = "res/Images/movement.png";
var s_sendScore = "res/Images/SendScoreButton.png";
var s_pressSendScore = "res/Images/SendScoreButtonPressed.png";
var s_power = "res/Images/powered.png";
var s_atlasTest = "res/Images/atlastest.png";
var s_stars2Grayscale = "res/Images/stars2-grayscale.png";
var s_starsGrayscale = "res/Images/stars-grayscale.png";
var s_grossini_dance_atlas = "res/Images/grossini_dance_atlas.png";
var s_piece = "res/Images/piece.png";
var s_grossini_dance_atlas_mono = "res/Images/grossini_dance_atlas-mono.png";

var s_grossini = "res/animations/grossini.png";
var s_grossini_gray = "res/animations/grossini_gray.png";
var s_grossini_blue = "res/animations/grossini_blue.png";
var s_grossini_aliases = "res/animations/grossini-aliases.png";
var s_dragon_animation = "res/animations/dragon_animation.png";
var s_ghosts = "res/animations/ghosts.png";
var s_grossini_family = "res/animations/grossini_family.png";
var s_texture512 = "res/Images/texture512x512.png";
var s_hole_effect_png = "res/Images/hole_effect.png";

var s_tcc_issue_1 = "res/animations/tcc_issue_1.png";
var s_tcc_issue_2 = "res/animations/tcc_issue_2.png";
var s_tcc_issue_1_plist = "res/animations/tcc_issue_1.plist";
var s_tcc_issue_2_plist = "res/animations/tcc_issue_2.plist";

var s_s9s_blocks9 = "res/Images/blocks9ss.png";
var s_s9s_blocks9_plist = "res/Images/blocks9ss.plist";

var s_s9s_ui = "res/Images/ui.png";
var s_s9s_ui_plist = "res/Images/ui.plist";
var s_circle_plist  = "res/Images/bugs/circle.plist";

var s_boilingFoamPlist = "res/Images/BoilingFoam.plist";
var s_grossiniPlist = "res/animations/grossini.plist";
var s_grossini_grayPlist = "res/animations/grossini_gray.plist";
var s_grossini_bluePlist = "res/animations/grossini_blue.plist";
var s_grossini_aliasesPlist = "res/animations/grossini-aliases.plist";
var s_ghostsPlist = "res/animations/ghosts.plist";
var s_grossini_familyPlist = "res/animations/grossini_family.plist";
var s_animations2Plist = "res/animations/animations-2.plist";
var s_animationsPlist = "res/animations/animations.plist";

var s_Cowboy_json = "res/armatures/Cowboy.ExportJson";
var s_Cowboy_plist = "res/armatures/Cowboy0.plist";
var s_Cowboy_png = "res/armatures/Cowboy0.png";
var s_cyborg_plist = "res/armatures/cyborg.plist";
var s_cyborg_png = "res/armatures/cyborg.png";
var s_cyborg_xml = "res/armatures/cyborg.xml";
var s_Dragon_plist = "res/armatures/Dragon.plist";
var s_Dragon_png = "res/armatures/Dragon.png";
var s_Dragon_xml = "res/armatures/Dragon.xml";
var s_knight_plist = "res/armatures/knight.plist";
var s_knight_png = "res/armatures/knight.png";
var s_knight_xml = "res/armatures/knight.xml";
var s_robot_plist = "res/armatures/robot.plist";
var s_robot_png = "res/armatures/robot.png";
var s_robot_xml = "res/armatures/robot.xml";
var s_weapon_plist = "res/armatures/weapon.plist";
var s_weapon_png = "res/armatures/weapon.png";
var s_weapon_xml = "res/armatures/weapon.xml";

var s_helloWorld = "res/Images/HelloWorld.png";
var s_grossiniDance01 = "res/Images/grossini_dance_01.png";
var s_grossiniDance02 = "res/Images/grossini_dance_02.png";
var s_grossiniDance03 = "res/Images/grossini_dance_03.png";
var s_grossiniDance04 = "res/Images/grossini_dance_04.png";
var s_grossiniDance05 = "res/Images/grossini_dance_05.png";
var s_grossiniDance06 = "res/Images/grossini_dance_06.png";
var s_grossiniDance07 = "res/Images/grossini_dance_07.png";
var s_grossiniDance08 = "res/Images/grossini_dance_08.png";
var s_grossiniDance09 = "res/Images/grossini_dance_09.png";
var s_grossiniDance10 = "res/Images/grossini_dance_10.png";
var s_grossiniDance11 = "res/Images/grossini_dance_11.png";
var s_grossiniDance12 = "res/Images/grossini_dance_12.png";
var s_grossiniDance13 = "res/Images/grossini_dance_13.png";
var s_grossiniDance14 = "res/Images/grossini_dance_14.png";

var s_arrows = "res/Images/arrows.png";
var s_arrowsBar = "res/Images/arrowsBar.png";
var s_arrows_hd = "res/Images/arrows-hd.png";
var s_arrowsBar_hd = "res/Images/arrowsBar-hd.png";

// tilemaps resource
var s_tilesPng = "res/TileMaps/tiles.png";
var s_levelMapTga = "res/TileMaps/levelmap.tga";
var s_fixedOrthoTest2Png = "res/TileMaps/fixed-ortho-test2.png";
var s_hexaTilesPng = "res/TileMaps/hexa-tiles.png";
var s_isoTestPng = "res/TileMaps/iso-test.png";
var s_isoTest2Png = "res/TileMaps/iso-test2.png";
var s_isoPng = "res/TileMaps/iso.png";
var s_orthoTest1BwPng = "res/TileMaps/ortho-test1_bw.png";
var s_orthoTest1Png = "res/TileMaps/ortho-test1.png";
var s_tilesHdPng = "res/TileMaps/tiles-hd.png";
var s_tmwDesertSpacingHdPng = "res/TileMaps/tmw_desert_spacing-hd.png";
var s_tmwDesertSpacingPng = "res/TileMaps/tmw_desert_spacing.png";
var s_fnTuffyBoldItalicCharmapPng = "res/fonts/tuffy_bold_italic-charmap.png";
var s_fpsImages = "res/fonts/fps_images.png";

var s_bitmapFontTest = "res/fonts/bitmapFontTest.png";
var s_bitmapFontTest2 = "res/fonts/bitmapFontTest2.png";
var s_bitmapFontTest3 = "res/fonts/bitmapFontTest3.png";
var s_bitmapFontTest4 = "res/fonts/bitmapFontTest4.png";
var s_bitmapFontTest5 = "res/fonts/bitmapFontTest5.png";
var s_konqa32 = "res/fonts/konqa32.png";
var s_konqa32_hd = "res/fonts/konqa32-hd.png";
var s_bitmapFontChinese = "res/fonts/bitmapFontChinese.png";
var s_arial16 = "res/fonts/arial16.png";
var s_larabie_16 = "res/fonts/larabie-16.png";
var s_larabie_16_hd = "res/fonts/larabie-16-hd.png";
var s_futura48 = "res/fonts/futura-48.png";
var s_arial_unicode_26 = "res/fonts/arial-unicode-26.png";

var s_bitmapFontTest_fnt = "res/fonts/bitmapFontTest.fnt";
var s_bitmapFontTest2_fnt = "res/fonts/bitmapFontTest2.fnt";
var s_bitmapFontTest3_fnt = "res/fonts/bitmapFontTest3.fnt";
var s_bitmapFontTest4_fnt = "res/fonts/bitmapFontTest4.fnt";
var s_bitmapFontTest5_fnt = "res/fonts/bitmapFontTest5.fnt";
var s_konqa32_fnt = "res/fonts/konqa32.fnt";
var s_konqa32_hd_fnt = "res/fonts/konqa32-hd.fnt";
var s_bitmapFontChinese_fnt = "res/fonts/bitmapFontChinese.fnt";
var s_arial16_fnt = "res/fonts/arial16.fnt";
var s_futura48_fnt = "res/fonts/futura-48.fnt";
var s_helvetica32_fnt = "res/fonts/helvetica-32.fnt";
var s_geneva32_fnt = "res/fonts/geneva-32.fnt";
var s_arial_unicode_26_fnt = "res/fonts/arial-unicode-26.fnt";
var s_markerFelt_fnt = "res/fonts/markerFelt.fnt";
var s_markerFelt_hd_fnt = "res/fonts/markerFelt-hd.fnt";

var s_larabie_16_plist = "res/fonts/larabie-16.plist";
var s_larabie_16_hd_plist = "res/fonts/larabie-16-hd.plist";
var s_tuffy_bold_italic_charmap = "res/fonts/tuffy_bold_italic-charmap.plist";
var s_tuffy_bold_italic_charmap_hd = "res/fonts/tuffy_bold_italic-charmap-hd.plist";

var s_particles = "res/Images/particles.png";
var s_particles_hd = "res/Images/particles-hd.png";
var s_texture512 = "res/Images/texture512x512.png";
var s_hole_effect_png = "res/Images/hole_effect.png";
var s_hole_stencil_png = "res/Images/hole_stencil.png";
var s_pathFog = "res/Images/Fog.png";
var s_circle_plist  = "res/Images/bugs/circle.plist";
var s_circle_png  = "res/Images/bugs/circle.png";

var s_extensions_background = "res/extensions/background.png";
var s_extensions_buttonBackground = "res/extensions/buttonBackground.png";
var s_extensions_button = "res/extensions/button.png";
var s_extensions_buttonHighlighted = "res/extensions/buttonHighlighted.png";
var s_extensions_ribbon = "res/extensions/ribbon.png";
var s_image_icon = "res/Images/Icon.png";

var g_resources = [];

var g_sprites = [];

var g_menu = [];

var g_touches = [];

var g_performace = [];

var g_fileUtils = [];

var g_s9s_blocks = [];

var g_opengl_resources = [];

var g_label = [];

var g_transitions = [];

var g_box2d = [];

var g_cocosdeshion = [];

var g_parallax = [];

var g_particle = [];

var g_fonts = [];

var g_extensions = [];

var g_tilemaps = [];
